# -*- coding: utf-8 -*-
"""
Created on Tue Aug 10 22:01:29 2021

@author: Nabeelah
"""

#https://www.dlology.com/blog/how-to-create-custom-coco-data-set-for-instance-segmentation/


# import package
import labelme2coco

# set directory that contains labelme annotations and image files
labelme_folder = "test"

# set path for coco json to be saved
save_json_path = "test/testval.json"

# convert labelme annotations to coco
labelme2coco.convert(labelme_folder, save_json_path)